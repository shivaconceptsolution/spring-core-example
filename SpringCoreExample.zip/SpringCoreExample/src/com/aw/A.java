package com.aw;

public class A {
    B b;
    A(){
        System.out.println("a is created");
    }

    A(B b)
    {
    this.b=b;
    System.out.println("Parametrised Constructor will be called");
    }
    public B getB()
    {
        return b;
    }
    public void setB(B b)
    {
        this.b = b;
    }
    void print(){
        System.out.println("hello a");
    }
    void display(){
        print();
        b.print();
    }

}
