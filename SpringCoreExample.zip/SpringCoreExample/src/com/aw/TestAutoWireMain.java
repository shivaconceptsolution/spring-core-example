package com.aw;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAutoWireMain {
    public static void main(String[] args) {
        ApplicationContext context=new ClassPathXmlApplicationContext("autoWiteContext.xml");
        A a=context.getBean("a",A.class);
        a.display();
    }
}
