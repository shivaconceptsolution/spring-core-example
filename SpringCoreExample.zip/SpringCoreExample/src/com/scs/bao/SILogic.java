package com.scs.bao;

public class SILogic {
    public float CalculateSI(float p,float r,float t)
    {
        return  (p*r*t)/100;
    }
}
