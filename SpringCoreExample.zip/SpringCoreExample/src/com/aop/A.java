package com.aop;

public class A  {
    public void m(){
        System.out.println("actual business logic");
    }


}
