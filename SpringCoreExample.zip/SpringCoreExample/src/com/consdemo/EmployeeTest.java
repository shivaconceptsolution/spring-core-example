package com.consdemo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class EmployeeTest {
    public static void main(String[] args) {
        Resource res = new ClassPathResource("empContext.xml");
        BeanFactory factory = new XmlBeanFactory(res);
        Employee s =(Employee) factory.getBean("si");
        s.showEmpList();
    }
}
