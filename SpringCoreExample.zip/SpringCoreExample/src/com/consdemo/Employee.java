package com.consdemo;

import java.util.List;

public class Employee {
    private int empid;
    private String empname;
    List lst;
    Employee()
    {

    }
    Employee(int empid)
    {
        this.empid=empid;
    }
    Employee(int empid,String empname)
    {
        this.empid = empid;
        this.empname=empname;
    }
    Employee(List lst)
    {
        this.lst=lst;
    }
    void showEmp()
    {
        System.out.println("Empid is "+this.empid + "Empname is "+this.empname);
    }
    void showEmpList()
    {
        for(Object o:lst)
        {
            System.out.println("Data is "+o);
        }
    }
}
